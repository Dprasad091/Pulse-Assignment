const express = require('express');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http'); 
const { Server } = require('socket.io'); 

// Import Routes
const userRoutes = require('./routes/userRoutes');
const videoRoutes = require('./routes/videoRoutes');

dotenv.config();

const app = express();
// Create HTTP server from the Express app (required for Socket.io)
const server = http.createServer(app); 

// Initialize Socket.io server
const io = new Server(server, {
  cors: {
    origin: 'http://localhost:5173', // Allow connections from your React frontend
    methods: ['GET', 'POST'],
  },
});

// Socket.io Connection Handler
io.on('connection', (socket) => {
  // Client emits 'joinRoom' with userId upon successful login
  socket.on('joinRoom', (userId) => {
    socket.join(userId);
    console.log(`Socket ${socket.id} joined room ${userId}`);
  });
  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
  });
});

// Make the Socket.io instance available to routes (like videoRoutes.js)
app.set('socketio', io); 

// --- Middleware ---
app.use(express.json()); // Body parser for JSON requests
app.use(cors({ origin: 'http://localhost:5173' })); // CORS configuration

// --- Database Connection ---
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB connected successfully.');
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    process.exit(1); // Exit process with failure code
  }
};
connectDB();

// --- Routes ---

// Basic Health Check Route
app.get('/', (req, res) => {
  res.send('API is running...');
});

// Register API Route Handlers
app.use('/api/users', userRoutes);
app.use('/api/videos', videoRoutes);

// --- Start Server ---
const PORT = process.env.PORT || 5000;
// Use server.listen (the combined HTTP/Socket.io server)
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));